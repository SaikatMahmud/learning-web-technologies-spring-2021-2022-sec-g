<?php $title = 'Social Medaia Home' ?>
<?php require_once 'components/header.php' ?>
<body>
    <table>
        <tr>
            <th colspan="2">Social Media Home</th>
        </tr>
        <tr>
            <td>Links</td>
            <td>
                <ul style="list-style-type: none;">
                    <li><a href="auth/login.php">Login</a></li>
                    <li><a href="auth/signup.php">Sign Up</a></li>
                    <li>About</li>
                </ul>
            </td>
        </tr>
    </table>
</body>
</html>