<html>
<body>

<h2>MARKETPLACE SELLER</h2>

<p align="right">
<a href=""> Enlist Product </a>
</p>
 <form method="POST" action="../others/enlistProduct.php">
  <tr>
  <th>Product</th>
    <th></th>
    <th></th>
  </tr>
  <tr>
    <td>Image <input type="file" name="myfile" value=" "></td>
    <td></td>
    </br>
  </tr>
  <tr>
    <td>Name<input type="text" name="name" value=""></td>
    <td></td>
     </br>
  </tr>
  
  <tr>
    <td>Description <input type="text" name="description" value=" "></td>
    <td></td>
     </br>
  </tr>
  <tr>
    <td>Price <input type="number" name="price" value=" "></td>
    <td></td>
     </br>
  </tr>
  <tr>
    <td>Category <input type="number" name="cat" value=" "></td>
    <td></td>
     </br>
  </tr>
  </br>
     <td>
        <input type="submit" name="submit" value="Submit">
      </td>
</form>

<p><a href="pagename">Requests</a></p>
<p><a href="pagename">Report</a></p>
<p><a href="pagename">logout</a></p>
<p><a href="pagename">Home</a></p>
<p><a href="pagename">Chat with Buyer</a></p>

</body>
</html>