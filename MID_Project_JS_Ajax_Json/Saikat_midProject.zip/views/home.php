<?php 
	//include("header.php");
	//include_once("header.php");

	require('header.php');
	//require_once('header.php');
?>

<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Welcome home!</h1> 

	<a href="create.php"> Create New User</a> |
	<a href="userlist.php"> User List</a> |
	<a href="../controllers/logout.php"> logout</a>

</body>
</html>
